package com.example.redenvelope;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import android.animation.ObjectAnimator;

public class EnvelopeAdapter extends RecyclerView.Adapter<EnvelopeAdapter.VH> {

    public interface OnEnvelopeOpenListener {
        void onEnvelopeOpened(int position, int value);
    }

    List<EnvelopeItem> items;
    OnEnvelopeOpenListener listener;

    public EnvelopeAdapter(List<EnvelopeItem> items, OnEnvelopeOpenListener l){
        this.items = items;
        this.listener = l;
    }

    @Override
    public VH onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_envelope, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(VH holder, int position){
        EnvelopeItem it = items.get(position);
        if (it.opened){
            holder.label.setText("R$ " + String.format("%.2f", it.cents/100.0));
            holder.container.setBackgroundResource(R.drawable.envelope_open_bg);
            holder.label.setTextColor(0xFF000000);
        } else {
            holder.label.setText("");
            holder.container.setBackgroundResource(R.drawable.envelope_closed_bg);
            holder.label.setTextColor(0xFFFFFFFF);
        }

        holder.container.setOnClickListener(view -> {
            if (!it.opened){
                int valueCents = 50 + (int)(Math.random() * 5000);
                it.opened = true;
                it.cents = valueCents;
                notifyItemChanged(position);

                ObjectAnimator.ofFloat(holder.container, "rotationY", 0f, 180f).setDuration(300).start();

                if (listener != null) listener.onEnvelopeOpened(position, valueCents);
            } else {
                if (listener != null) listener.onEnvelopeOpened(position, it.cents);
            }
        });
    }

    @Override
    public int getItemCount(){ return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        View container;
        TextView label;
        VH(View v){
            super(v);
            container = v.findViewById(R.id.envelope_container);
            label = v.findViewById(R.id.envelope_label);
        }
    }
}
