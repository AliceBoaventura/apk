package com.example.redenvelope;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements EnvelopeAdapter.OnEnvelopeOpenListener {

    RecyclerView recycler;
    EnvelopeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new GridLayoutManager(this, 3));

        List<EnvelopeItem> items = new ArrayList<>();
        for (int i=0;i<12;i++){
            items.add(new EnvelopeItem(false, 0));
        }

        adapter = new EnvelopeAdapter(items, this);
        recycler.setAdapter(adapter);
    }

    @Override
    public void onEnvelopeOpened(int position, int value) {
        Toast.makeText(this, "Envelope " + (position+1) + " = R$ " + String.format("%.2f", value/100.0), Toast.LENGTH_SHORT).show();
    }
}
