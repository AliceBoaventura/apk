package com.example.redenvelope;

public class EnvelopeItem {
    public boolean opened;
    public int cents;

    public EnvelopeItem(boolean opened, int cents) {
        this.opened = opened;
        this.cents = cents;
    }
}
