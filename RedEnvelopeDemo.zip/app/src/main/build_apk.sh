#!/usr/bin/env sh
set -e
echo "Building debug APK..."
chmod +x ./gradlew || true
./gradlew clean assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
